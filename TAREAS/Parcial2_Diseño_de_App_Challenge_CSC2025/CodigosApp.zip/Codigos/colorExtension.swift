import SwiftUI

// Definimos los colores personalizados de la app para usarlos fácilmente
extension Color {
    static let appBackground = Color.black
    static let primaryUI = Color(red: 0.1, green: 0.12, blue: 0.18) // Azul oscuro para botones
    static let accentYellow = Color(red: 0.98, green: 0.78, blue: 0.0)
    static let translationBrown = Color(red: 0.5, green: 0.35, blue: 0.2) // Café/naranja para la traducción
}