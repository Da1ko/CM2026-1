import SwiftUI

struct ConversationView: View {
    var body: some View {
        ZStack {
            Color.appBackground.edgesIgnoringSafeArea(.all)
            
            ScrollView {
                VStack(spacing: 20) {
                    // Burbuja de Persona A
                    ChatBubbleView(
                        person: "Persona A",
                        original: "Hello, how are you today?",
                        traduccion: "Hola, ¿cómo estás hoy?",
                        isPersonA: true
                    )
                    
                    // Botón de Micrófono
                    Button(action: {
                        // TODO: Iniciar/detener detección de voz
                    }) {
                        HStack {
                            Image(systemName: "mic.fill")
                            Text("Detectando: Español")
                                .fontWeight(.semibold)
                        }
                        .padding(.vertical, 12)
                        .padding(.horizontal, 25)
                        .background(Color.accentYellow)
                        .foregroundColor(.black)
                        .cornerRadius(30)
                    }
                    
                    // Burbuja de Persona B (ejemplo)
                    ChatBubbleView(
                        person: "Persona B",
                        original: "Estoy bien, ¿y tú?",
                        traduccion: "I'm fine, and you?",
                        isPersonA: false
                    )
                }
                .padding()
            }
        }
        .navigationTitle("Conversación")
        .navigationBarTitleDisplayMode(.inline)
    }
}

// Vista reutilizable para las burbujas de chat
struct ChatBubbleView: View {
    let person: String
    let original: String
    let traduccion: String
    let isPersonA: Bool
    
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Text(person)
                    .font(.headline)
                    .foregroundColor(.white)
                Circle()
                    .frame(width: 10, height: 10)
                    .foregroundColor(isPersonA ? .blue : Color.accentYellow)
                Spacer()
            }
            
            Text("Original:")
                .font(.caption)
                .foregroundColor(.gray)
            Text("\"\(original)\"")
                .font(.body)
                .foregroundColor(.white)
            
            // Bloque de traducción
            VStack(alignment: .leading, spacing: 5) {
                Text("Traducción:")
                    .font(.caption)
                    .foregroundColor(.white.opacity(0.8))
                Text("\"\(traduccion)\"")
                    .font(.headline)
                    .fontWeight(.bold)
                    .foregroundColor(.white)
            }
            .padding()
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(Color.translationBrown)
            .cornerRadius(10)
        }
        .padding()
        .background(Color.primaryUI)
        .cornerRadius(15)
    }
}