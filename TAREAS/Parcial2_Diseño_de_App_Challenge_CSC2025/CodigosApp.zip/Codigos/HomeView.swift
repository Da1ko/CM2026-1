import SwiftUI

struct HomeView: View {
    var body: some View {
        ZStack {
            Color.appBackground.edgesIgnoringSafeArea(.all)
            
            VStack(spacing: 30) {
                // Cabecera
                HStack {
                    VStack(alignment: .leading) {
                        Text("InclusiveMatch AI")
                            .font(.title)
                            .fontWeight(.bold)
                        Text("Idioma: Español")
                            .font(.subheadline)
                            .foregroundColor(.gray)
                    }
                    Spacer()
                    Button(action: {
                        // TODO: Acción para abrir Ajustes
                    }) {
                        Image(systemName: "gearshape.fill")
                            .font(.title2)
                            .foregroundColor(.white)
                    }
                }
                .padding(.horizontal)
                
                Spacer()
                
                // Botón Modo Conversación
                NavigationLink(destination: ConversationView()) {
                    VStack(spacing: 10) {
                        Image(systemName: "mic.fill")
                            .font(.system(size: 40))
                        Text("Modo Conversación")
                            .font(.title2)
                            .fontWeight(.bold)
                        Text("Traduce conversaciones en tiempo real")
                            .font(.caption)
                            .foregroundColor(.black.opacity(0.7))
                    }
                    .frame(maxWidth: .infinity, minHeight: 180)
                    .background(Color.accentYellow)
                    .foregroundColor(.black)
                    .cornerRadius(20)
                }
                
                // Botón Modo Visual
                NavigationLink(destination: VisualModeView()) {
                    HStack {
                        Image(systemName: "camera.fill")
                            .font(.system(size: 24))
                        Text("Modo Visual")
                            .font(.title3)
                            .fontWeight(.semibold)
                    }
                    .frame(maxWidth: .infinity, minHeight: 70)
                    .background(Color.primaryUI)
                    .foregroundColor(.white)
                    .cornerRadius(15)
                }

                Spacer()
            }
            .padding()
        }
        // Ocultamos la barra de navegación en esta pantalla
        .navigationBarHidden(true)
    }
}