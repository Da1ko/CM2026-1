import SwiftUI

struct LanguageSelectionView: View {
    // Binding para notificar al ContentView que el usuario ha terminado aquí
    @Binding var isLanguageSelected: Bool

    var body: some View {
        ZStack {
            Color.appBackground.edgesIgnoringSafeArea(.all)

            VStack(spacing: 20) {
                Spacer()
                
                // Icono de la App (usamos un SFSymbol como placeholder)
                Image(systemName: "bubble.left.and.bubble.right.fill")
                    .font(.system(size: 80))
                    .foregroundColor(Color.accentYellow)
                
                Text("InclusiveMatch AI")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .foregroundColor(.white)
                
                Text("Traducción accesible en tiempo real")
                    .font(.headline)
                    .foregroundColor(.gray)
                
                Spacer()
                
                Text("Selecciona tu idioma materno")
                    .font(.title2)
                    .fontWeight(.semibold)
                    .foregroundColor(.white)
                
                // Botón de idioma
                Button(action: {
                    // TODO: Guardar "Español" como idioma materno
                    isLanguageSelected = true
                }) {
                    HStack {
                        Text("ES").fontWeight(.bold)
                        Text("Español")
                        Spacer()
                    }
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.primaryUI)
                    .foregroundColor(.white)
                    .cornerRadius(10)
                }
                
                // Botón de idioma
                Button(action: {
                    // TODO: Guardar "English" como idioma materno
                    isLanguageSelected = true
                }) {
                    HStack {
                        Text("US").fontWeight(.bold)
                        Text("English")
                        Spacer()
                    }
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.primaryUI)
                    .foregroundColor(.white)
                    .cornerRadius(10)
                }
                
                Spacer().frame(height: 40)
            }
            .padding()
        }
    }
}