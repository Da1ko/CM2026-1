import SwiftUI

struct VisualModeView: View {
    var body: some View {
        ZStack {
            // Placeholder para la vista de la cámara
            // TODO: Reemplazar esto con la vista de cámara real (AVFoundation)
            Color.gray
                .edgesIgnoringSafeArea(.all)
                .overlay(Text("Vista de Cámara").foregroundColor(.white))
            
            VStack {
                // Botón de escaneo
                Button(action: {
                    // TODO: Lógica de escaneo
                }) {
                    HStack {
                        Image(systemName: "camera")
                        Text("Escaneando texto...")
                            .fontWeight(.semibold)
                    }
                    .padding(.vertical, 10)
                    .padding(.horizontal, 20)
                    .background(Color.accentYellow)
                    .foregroundColor(.black)
                    .cornerRadius(30)
                }
                .padding(.top)
                
                Spacer()
                
                // Caja de traducción detectada
                VStack(alignment: .leading, spacing: 12) {
                    HStack {
                        Image(systemName: "bolt.fill")
                            .foregroundColor(Color.accentYellow)
                        Text("Traducción detectada")
                            .font(.headline)
                            .foregroundColor(.white)
                    }
                    
                    Text("RESTAURANT")
                        .font(.title)
                        .fontWeight(.bold)
                        .foregroundColor(.white)
                    
                    Text("Today's Menu")
                        .font(.title3)
                        .fontWeight(.semibold)
                        .foregroundColor(.white)
                    
                    VStack(alignment: .leading, spacing: 5) {
                        Text("• Valencian Paella - €15")
                        Text("• Andalusian Gazpacho - €8")
                    }
                    .font(.body)
                    .foregroundColor(.white)
                    
                }
                .padding(20)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(Color.black.opacity(0.8))
                .cornerRadius(15)
                .overlay(
                    RoundedRectangle(cornerRadius: 15)
                        .stroke(Color.accentYellow, lineWidth: 3)
                )
                .padding()
            }
        }
        .navigationTitle("Modo Visual")
        .navigationBarTitleDisplayMode(.inline)
    }
}