import SwiftUI

@main
struct InclusiveMatchApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

struct ContentView: View {
    // Estado para saber si el usuario ya pasó de la selección de idioma
    @State private var isLanguageSelected = false

    var body: some View {
        if isLanguageSelected {
            // Si ya seleccionó, mostramos la app principal dentro de un NavigationStack
            NavigationStack {
                HomeView()
            }
            .preferredColorScheme(.dark) // Forzamos el modo oscuro como en las capturas
        } else {
            // Si no, mostramos la pantalla de selección
            LanguageSelectionView(isLanguageSelected: $isLanguageSelected)
                .preferredColorScheme(.dark)
        }
    }
}